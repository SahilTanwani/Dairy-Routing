# TASKS

Work these **in order**, one at a time. Mark `[x]` when done and commit.

**Time budget: ~24 working hours.** Scoped accordingly. See the cut list at the bottom.

---

## Phase 0 — Foundation (~1.5 h)

- [x] **T0.1** · Write `ASSUMPTIONS.md`
- [x] **T0.2** · Generate Spring Boot project (Boot 4.0.8, Java 21, springdoc 3.0.3)
- [x] **T0.3** · `git init`, `.gitignore` (`target/ .idea/ *.iml *.log`), first commit
- [x] **T0.4** · **`ClockProvider` interface + `SystemClock`** ← do not skip or defer

      config/ClockProvider.java   — interface, one method: Instant now()
      config/SystemClock.java     — @Component @Profile("!sim")

      RULE FROM HERE ON: Instant.now() appears exactly once, inside SystemClock.

- [x] **T0.5** · `docker-compose.yml` (postgres:16-alpine + healthcheck) and `Dockerfile`
      (two-stage, `dependency:go-offline` in its own layer)
- [x] **T0.6** · `application.yml` — datasource from env with local defaults,
      `ddl-auto: validate`, `open-in-view: false`
- [x] **T0.7** · `V1__baseline.sql` (trivial table) + `GET /api/v1/health` using
      `ClockProvider`
- [x] **T0.8** · **Clean-machine check #1** — clone your own repo elsewhere,
      `docker compose up --build`, curl health
- [x] **T0.9** · Package skeleton, including all `domain/` subpackages

      RULE: nothing in domain/ imports org.springframework

**Done when:** fresh clone → `docker compose up` → `GET /api/v1/health` returns 200.

---

## Phase 1 — Schema (~2 h)

- [x] **T1.1** · `V2__master_data.sql` — village, collection_point, farmer, plant,
      tanker, driver, temperature_profile, solver_parameter. All indexes and CHECKs
      from `docs/02-schema.md`.
- [x] **T1.2** · `V3__planning.sql` — route_plan, route, route_stop.
      **Include `uq_one_published_per_session`.**
- [x] **T1.3** · `V4__coverage.sql` — point_coverage_state, plan_exclusion
- [x] **T1.4** · `V5__operations.sql` — trip, trip_stop, collection, driver_event,
      tanker_ping, alert, intake_record.
      **Include `client_event_id UUID UNIQUE` and `uq_alert_open`.**
- [x] **T1.5** · ~~`V6__advisory.sql` — merge_proposal, merge_proposal_point~~
      **Withdrawn.** Built, then removed with the consolidation advisory: nothing
      in scope writes those two tables. The schema is V1-V5.
- [x] **T1.6** · JPA entities, one per table. `@Version` on Trip.
- [x] **T1.7** · Enums — Session, TripStatus, TripStopStatus, EventType, RiskLevel,
      SkipReason, PlanStatus, PlanMode, EtaConfidence, AlertType, AlertSeverity,
      ExclusionReason
- [x] **T1.8** · Repositories — query methods for available tankers, active points by
      village, published plan by session, active trips

**Done when:** `docker compose down -v && docker compose up` runs all migrations cleanly
and Hibernate validation passes with no schema mismatch.

---

## Phase 2 — Seed data (~3 h)

- [x] **T2.1** · `DatasetConfig` + `Range` records
- [x] **T2.2** · `DatasetLoader` — reads `classpath:datasets/{name}.yaml` via SnakeYAML
- [x] **T2.3** · `GeoPoint` record + Haversine + `project(from, bearing, km)`, with tests
      against known distances
- [x] **T2.4** · Seed villages — corridor placement, uneven bearings, growing gaps,
      fixed `Random(seed)`
- [x] **T2.5** · Seed collection points — scatter within village radius
- [x] **T2.6** · Seed farmers — `twoFarmerPointRatio` chance of 2; compute
      `service_minutes = 2.0 + 0.35 × count` and morning/evening litres
- [x] **T2.7** · Seed fleet, drivers, plant — round-robin `capacityMix`, first N insulated
- [x] **T2.8** · Seed temperature profiles (24 rows) + the 20 solver parameters
- [x] **T2.9** · `SeedRunner` — `ApplicationRunner`, skips if data exists
- [x] **T2.10** · Reseed endpoint — `POST /api/v1/admin/reseed?dataset=X`.
      **Load config before truncating. Clear the matrix cache. Guard to dev/sim.**
- [x] **T2.11** · Write `baseline.yaml`
- [x] **T2.12** · `GET /api/v1/admin/dataset-check` — counts, required vs available hot minutes
      and ratio, volume vs capacity, unreachable count, farthest village km

**Done when:** 60 villages, ~1,250 points, ~1,400 farmers; dataset-check shows time
ratio < 0.8.

---

## Phase 3 — The two calculations (~2 h)

- [x] **T3.1** · `TravelTimeProvider` interface (plain Java, `domain/geo/`)
- [x] **T3.2** · `HaversineTravelTime` — circuity 1.35, speeds 15/26/34, morning ×1.15 /
      evening ×0.90, all params injected from `solver_parameter`
- [x] **T3.3** · Travel time tests — the worked example: 10.4 km straight → 14.0 km road
      → 21.5 min morning, 27.4 min evening
- [x] **T3.4** · `TravelMatrix` + cache keyed by SHA-256 of the sorted point set
- [ ] **T3.5** · `SpoilageCalculator` — Q10 formula with min/max clamps
- [ ] **T3.6** · **`SpoilageCalculator` tests** ← test hardest

      18→414, 22→313, 27→222, 30→180, 35→127, 39→96
      (35, insulated) → 193; (22, insulated) → 475, just under the ceiling
      (10, false) → 480 ceiling; (55, false) → 60 floor

- [x] **T3.7** · ~~`AmbientTemperatureProvider` interface + impl~~
      **Built as `AmbientTemperatureService`** — reads `temperature_profile`, plus a shift
      model (`ambientShiftCPerHour`) the table cannot supply, since it is month-by-session
      and the timing advisory turns on the difference between 16:30 and 18:30.

**Done when:** both calculators pass their full test suites. Everything downstream
depends on these being right.

---

## Phase 4 — The planner (~5 h) ← this will overrun; protect it

- [ ] **T4.1** · `PlanningContext` record
- [ ] **T4.2** · Four `RouteConstraint` implementations — Spoilage, Capacity,
      ShiftLength, PlantWindow
- [ ] **T4.3** · **`ConstraintChecker`** ← the class they will read most closely.
      Hot time **excludes** the plant → first-village leg.
- [ ] **T4.4** · `ConstraintChecker` tests — one per constraint, plus boundary:
      exactly at `budget − buffer` passes, one minute over fails
- [ ] **T4.5** · `VillageBlock` record
- [x] **T4.6** · `VillageSolver` — nearest-neighbour + 2-opt; split oversized blocks
- [x] **T4.7** · `FeasibilityAssessor` — required vs available → mode selection
- [x] **T4.8** · `PlanningStrategy` interface
- [x] **T4.9** · `RoutePlanner` (full-service) — savings over blocks, greedy merge
- [ ] **T4.10** · `SequenceOptimiser` — farthest-first seed + 2-opt on **hot time**
      (Or-opt is optional, cut if short)
- [x] **T4.11** · `TankerAssigner` — riskiest route gets the largest hold budget
- [x] **T4.12** · `PlanResult` + `FeasibilityReport`

**Done when:** `POST /api/v1/plans` at 22 °C serves all points in under 5 s using fewer than 22
tankers.

**Actual:** 193 ms. Three defects were found by wiring Phase 6 on top of this phase, and
all three are now fixed:

1. **`FeasibilityAssessor` ignored shift length.** It compared hot minutes against hold
   budget only, so it reported FULL_SERVICE at 22 °C while the 300-minute driver shift made
   full service impossible. Each tanker now contributes `min(holdBudget, driverShift)`; at
   22 °C that is 300 rather than 313, giving a ratio of 1.06 and COVERAGE_OPTIMISATION.

2. **`TankerAssigner` paired routes with tankers that could not run them.** The merge loop
   validated against the *least capable tanker that passes*; the assigner then paired by hot
   time against hold budget without re-checking, producing a route with **-44 minutes of
   slack** — booked to reach the plant after its own milk had spoiled. It now re-checks each
   pairing with `ConstraintChecker` and leaves the route unassigned instead. A rejected route
   does not consume the tanker it refused. `TankerAssignerTest`.

3. **The merge loop built more insulated-only routes than there are insulated tankers.**
   Every merge was individually feasible — some tanker could run it — but six insulated
   tankers cannot crew a dozen insulated-only routes, so the assigner refused them and
   coverage collapsed. Before accepting a merge, the loop now sorts the resulting hot times
   against the fleet's usable budgets and rejects the merge if the demanding routes would
   outnumber the tankers able to take them. Only the top `fleetSize` demands are checked:
   requiring the whole set to be crewable would block every merge at the start, when there
   are 60 routes and 22 tankers. `RoutePlannerFleetFitTest`.

**Where that leaves the plan:** 22 routes and 868 of 1,250 points at 22 °C on the seeded
300-minute roster, thinnest slack +93. On a 600-minute roster, 22 routes and **1,216 of
1,250 points**, mode FULL_SERVICE, thinnest slack +31. The morning shortfall is the driver
roster, not the fleet — see `ASSUMPTIONS.md` section 5.

## Phase 5 — Coverage mode (~2 h)

**Reduced scope.** No `PointScorer` class and no `CoveragePlanner` class. The scoring is
the merge ordering inside `RoutePlanner`, and coverage mode is that same loop degrading
honestly rather than a second algorithm. Partial fill and ejection chains are cut.

- [x] **T5.1** · ~~`PointScorer` — efficiency × equity × urgency~~
      **Built as `RoutePlanner.candidates()`** — `litres / marginalHotMinutes ×
      (1 + daysSinceLastServed) ^ equityExponent`, with `equityExponent` and
      `maxConsecutiveSkips` read from `solver_parameter`. No urgency term: the equity
      term already covers a point skipped last session.
- [x] **T5.2** · ~~`PointScorer` tests~~
      **Built as `RoutePlannerCoverageTest`** — mirror-image villages where efficiency is
      a wash, so only the history can decide which one is served. Verified by
      neutralising `equityExponent`, which makes one of the mirrored pair fail.
- [x] **T5.3** · ~~`CoveragePlanner` — mandatory-first seeding, greedy village insertion,
      partial fill~~
      **Not built.** Mandatory-first and greedy village ordering live in the merge
      ranking; a village at `maxConsecutiveSkips` is merged before anything is ranked.
      Partial fill and ejection chains are deliberately omitted — see
      `docs/03-algorithms.md`.
- [x] **T5.4** · `CoverageStateService` — resets `consecutive_skips` and sets
      `last_served_date` for served points, increments for the rest. Runs on **publish**,
      not on generate, so a discarded draft never marks a village as collected.
- [x] **T5.5** · One `plan_exclusion` row per unserved point, reason `COVERAGE_LIMIT`,
      with litres forgone. `GET /api/v1/plans/{id}/exclusions` lands with `PlanController` in
      T6.3, which is where the plan id comes from.

**Done when:** 35 °C switches to `COVERAGE_OPTIMISATION` automatically, `PlanResult`
reports `pointsServed` / `pointsTotal` / `coveragePct` / `litresCollected` /
`litresTotal`, and exclusions carry reasons.

**Not wired yet:** `CoverageStateService` has no caller until `PlanningService` (T6.1)
persists and publishes a plan.

---

## Phase 6 — Plans and the timing advisory (~1.5 h)

- [x] **T6.1** · `PlanningService` — build context, pick strategy, persist plan + routes
      + stops
- [x] **T6.2** · Publish endpoint — verify `uq_one_published_per_session` rejects a
      second publish
- [x] **T6.3** · `PlanController` — POST /api/v1/plans, GET /plans/{id}, GET feasibility,
      POST publish, GET published
- [x] **T6.4** · **`TimingAdvisory`** ← 20 minutes, best line in the demo
- [x] **T6.5** · `AdvisoryController`

**Done when:** timing advisory on `heat-crisis` shows 19% → 37% at zero cost.

**Actual on `baseline` at 35 °C:** 16:30 / 127 min / **19%** → 18:30 / 193 min / **37%**,
a gain of 18 points at zero cost. Temperatures and budgets are exactly as specified; the
coverage figures are lower than the 67% → 91% estimate because that assumed spoilage was
the only binding constraint. The 300-minute driver shift and the 22:00 plant close bite
too. See `ASSUMPTIONS.md` section 5.

---

## ═══ SLEEP HERE — 8 hours, non-negotiable ═══

The quality drop from working through is visible in a diff and it is the first thing a
reviewer notices.

---

## Phase 7 — Trips and events (~3 h)

- [x] **T7.1** · Trip creation — read published plan, **snapshot route_stops into
      trip_stops**, check tanker/driver availability, substitute or BLOCK
- [x] **T7.2** · `TripStateMachine` — allowed-transitions map
- [x] **T7.3** · `TripStateMachine` tests — every valid transition, sample invalid ones
- [x] **T7.4** · Event DTOs — batch request with `clientEventId`, type, `clientTs`,
      payload
- [x] **T7.5** · **`EventIngestionService`** ← the idempotency piece.
      `@Transactional`, sort by `client_ts`, catch `DataIntegrityViolationException`
- [x] **T7.6** · `EventReplayer` — apply each event type; synthesise a missing
      `ARRIVED_AT_STOP` before a `COLLECTED`
- [x] **T7.7** · **Idempotency test** — 30 events, resend 5, assert 25 applied /
      5 duplicates / no double collections
- [x] **T7.8** · Collection recording — one row per farmer, validated 0–500
- [x] **T7.9** · `DriverController` — today's trip, events, pings, own clock

**Done when:** you can curl a sequence of events and watch a trip progress.

**Done.** Five events against trip 1 move it SCHEDULED to IN_PROGRESS, stop 1 to COLLECTED
with one milk row, stop 2 to ARRIVED, currentSeq 2, and the spoilage deadline set from the
first collection. Resending the same batch: 0 applied, 5 duplicates, still one milk row.

**Deviation worth knowing.** T7.5 specifies catching `DataIntegrityViolationException` to
count a duplicate. That does not work: Postgres aborts a transaction on a failed statement,
so the events behind the duplicate would be lost with it. Duplicates are absorbed by
`INSERT ... ON CONFLICT (client_event_id) DO NOTHING` instead — the same unique index is
still the arbiter, the transaction stays usable, and it is correct when two copies of a
batch arrive at once.

---

## Phase 8 — Tracking and monitoring (~2 h)

- [x] **T8.1** · `PingService` — batch ingest, update trip's last position
- [x] **T8.2** · `PositionResolver` — events drive progress, pings refine
- [x] **T8.3** · `EtaCalculator` — with the clamped delay factor
- [x] **T8.4** · `EtaCalculator` tests — happy path, with delay, with skipped stops
- [x] **T8.5** · Confidence rules — HIGH / MEDIUM / LOW / LOST
- [x] **T8.6** · `FarmerQueryService` — all nine statuses with message templates,
      `guaranteedBy` from the three-strike rule
- [x] **T8.7** · `FarmerController` — tanker-status, collections
- [x] **T8.8** · `SpoilageMonitorService` — `@Scheduled` 60 s, 80%/95% thresholds,
      **one-way ratchet**, tracking-lost keeps counting
- [x] **T8.9** · `AlertService` — raise with `dedupe_key`, update if already open
- [x] **T8.10** · `Mitigation` sealed interface + SkipRemaining, DivertToPlant,
      ContinueAsPlanned
- [x] **T8.11** · `MitigationService` — generate, rank by litres saved, execute with
      optimistic locking. **Never auto-execute.**
- [x] **T8.12** · `OpsController` + `GET /api/v1/ops/board` facade

**Done when:** a delayed trip escalates WARNING → CRITICAL and offers ranked mitigations
with real numbers.

**Done.** A trip three hours behind on a 35 °C morning goes CRITICAL, sorts to the top of
the board, and raises one alert: "Projected 381 minutes of milk age against a 193 minute
budget (197%)". Its mitigations come back ranked and honest — SKIP_REMAINING saves 40 L
but still lands at 337 minutes, CONTINUE_AS_PLANNED arrives 188 minutes over — with
`anySaves: false` and the summary "No option gets this load to the plant inside its
budget." Executing with a stale version returns 409; with the right one it defers 20 stops
and moves the trip to RETURNING.

**Q6 is not reachable.** The nine farmer statuses assume a point can be merged into a hub,
but `collection_point.merged_into_id` was removed with the consolidation advisory, so there
is no way to reach that state and no honest branch to write. Eight are implemented.

---

## Phase 9 — Minimal simulation (~2 h)

Deliberately reduced. Skip driver personalities, the farmer caller, the separate plant
operator class, and the random connectivity model.

- [ ] **T9.1** · `VirtualClock` — `@Profile("sim")`, advance and jumpTo
- [ ] **T9.2** · `VirtualDriver` — walks its route, POSTs events and pings through the
      **real HTTP API**. Never writes to the database directly.
- [ ] **T9.3** · Offline buffering — one hardcoded signal-loss window. On reconnect send
      the backlog **plus 3 already-acked events** to prove dedupe. Log the counts.
- [ ] **T9.4** · `SimulationEngine` — advance clock in 30 s steps, tick drivers, sweep
      the monitor, recompute ETAs
- [ ] **T9.5** · `SimulationController` — run, pause, jumpTo, status
- [ ] **T9.6** · Two scenarios — `happy-morning` and `spoilage-crisis`
- [ ] **T9.7** · Write `heat-crisis.yaml` (**same seed as baseline**) and
      `sparse-district.yaml`
- [ ] **T9.8** · **Tune the datasets** — run dataset-check on each. `sparse-district`
      must produce ≥ 5 unreachable villages. Write expected numbers as a comment at the
      top of each YAML.

**Done when:** `POST /api/v1/sim/run` completes a session and `spoilage-crisis` produces exactly
one CRITICAL alert with zero rejected litres.

---

## Phase 10 — Ship it (~2 h)

- [ ] **T10.1** · `demo.sh` — the three-dataset sequence with curl and commentary
- [ ] **T10.2** · **Magic number sweep** — grep for hardcoded 22, 60, 1400, 1250, 180,
      1.35. Everything from config or `solver_parameter`.
- [ ] **T10.3** · **Clean-machine check #2** — `docker system prune -a`, fresh clone,
      full run, `./demo.sh`
- [ ] **T10.4** · `README.md`

      Order: what it is · how to run · THE FEASIBILITY FINDING (lead with it) ·
      assumptions · domain model · spoilage model · algorithm with the farthest-first
      worked example · coverage and why litre-maximisation is wrong · user permission
      matrix · edge cases · WHAT I DID NOT BUILD AND WHY · known limitations ·
      next two weeks

- [ ] **T10.5** · Final commit and push

---

## Known limitations

Things that are wrong in a bounded, understood way. The README's *known limitations*
section draws from here.

**The ETA delay factor can read a driver as faster than he is.** `EtaCalculator`
measures pace by comparing actual against planned arrival across the completed stops —
the span from the first collected stop to the last. If stops were skipped in between,
the *planned* span still includes their service time and their legs, while the *actual*
span does not, so the ratio comes out low and the driver looks quicker than he really
is. Every later ETA is then slightly optimistic, which is the wrong direction to be
wrong in when the number is being read to a farmer.

The size of it is bounded: the factor is clamped at 0.7, so the worst case is a 30%
optimistic estimate rather than an arbitrary one, and the effect only appears on trips
that have skipped stops mid-run. The fix is to compare against the planned span of the
stops *actually visited* rather than the whole interval, which needs per-stop planned
legs rather than just arrival times.

**`temperature_profile` is one figure per month per session.** Ambient cannot move
during a trip unless something passes an override into `SpoilageMonitorService.check`.
The simulation and the ratchet test do; a real deployment would pass a weather reading.
Without one, the one-way ratchet never fires in production.

**Farmer status Q6 is unreachable.** A point merged into a hub has no representation
since `collection_point.merged_into_id` was removed with the consolidation advisory.
Eight of the nine statuses are implemented.

---

## Cut list — in this order if running behind

1. Or-opt in `SequenceOptimiser` (T4.10) — the farthest-first seed does most of the work
2. `sparse-district` dataset (T9.7) — keep baseline and heat-crisis
3. `spoilage-crisis` scenario (T9.6) — keep happy-morning
4. `DivertToPlant` mitigation — keep SkipRemaining and ContinueAsPlanned
5. The whole of Phase 9 — demo with curl and logs instead

## Never cut

- `ConstraintChecker` and its tests (T4.3, T4.4)
- `SpoilageCalculator` and its tests (T3.5, T3.6)
- Farmer status endpoint (T8.6, T8.7)
- Event idempotency and its test (T7.5, T7.7)
- The equity term and three-strike rule (T5.1, T5.4)
- Clean-machine verification (T0.8, T10.3)
- `README.md` (T10.4)

---

## The five things that must exist at the end

1. `docker compose up` works from a fresh clone
2. `POST /api/v1/plans` produces routes at 22 °C and switches to coverage mode at 35 °C
3. `GET /api/v1/farmers/{code}/tanker-status` returns a plain-English sentence
4. Event idempotency demonstrably works
5. README explains the evening-is-impossible finding

Everything else is bonus.

---

## Working rules

- Commit every 45 minutes with a descriptive message. Git history gets read.
- Read every file before committing it. If a method does not make sense to you, ask for
  a simpler version or write it yourself.
- Modify something yourself in each of: `ConstraintChecker`, `SpoilageCalculator`,
  `RoutePlanner.candidates()`, `EventIngestionService`, `EtaCalculator`. Nothing cements
  understanding like editing code.
- Keep a scratch file of README sentences as you make decisions. At hour 22 you will be
  too tired to reconstruct your reasoning.
- If a task overruns by more than 50%, cut something from the list above. Do not cut
  sleep and do not cut the README.
